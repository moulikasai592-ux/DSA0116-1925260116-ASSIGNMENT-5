#include <iostream>
#include <string>

class Bill {
public:
    virtual ~Bill() = default;
    virtual double total() const = 0;
};

class EmergencyBill : public Bill {
    double baseCharge;
    double timeCharge;
public:
    EmergencyBill(double base, double time)
        : baseCharge(base), timeCharge(time) {}
    double total() const override { return baseCharge + timeCharge; }
};

class Payer {
public:
    virtual ~Payer() = default;
    virtual double amountCovered(const Bill& bill) const = 0;
};

class CorporatePayer : public Payer {
public:
    double amountCovered(const Bill& bill) const override {
        return bill.total() * 0.80;
    }
};

int main() {
    EmergencyBill bill(3000, 7000);
    CorporatePayer payer;

    const double covered = payer.amountCovered(bill);
    std::cout << "Bill total: " << bill.total() << '\n';
    std::cout << "Corporate covered: " << covered << '\n';
    std::cout << "Patient pays: " << bill.total() - covered << '\n';
}
