# B4 Final Engineering Decision

The polymorphic design is suitable for a hospital billing system that adds bill and payer types regularly. New derived classes can implement the common interfaces without changing existing bill and payer classes. A virtual destructor supports safe deletion through base pointers. RAII and exception handling improve resource safety and error recovery.

For production, expected validation failures should generally use clear return/status results where they are frequent; exceptions can handle exceptional failures. Configuration files are appropriate for changing rates and package rules, while new complex behaviour may require tested C++ code.

Before production use, add persistent storage, audit logging, access control, input validation, automated tests, concurrency controls and thorough performance/security testing.
