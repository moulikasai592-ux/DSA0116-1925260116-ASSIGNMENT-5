# DSA01-1925260163-Assignment5

**Assignment:** Assignment 5 – CO5: Reliable Software with Runtime Polymorphism and Exceptions  
**Student:** K. Sai Moulika  
**Register Number:** 1925260163  
**Language:** C++17  
**Compiler:** g++ (enter your installed version below)

## Compile
```bash
g++ --version
g++ -std=c++17 -Wall -Wextra Task01/main.cpp -o Task01/program
```

## Run
Linux/macOS:
```bash
./Task01/program
```
Windows PowerShell:
```powershell
g++ -std=c++17 -Wall -Wextra Task01/main.cpp -o Task01/program.exe
.\Task01\program.exe
```

## Folder structure
- `PartA/` – written design answers, pseudocode and complexity comparisons.
- `Task01/` – polymorphic billing implementation (B1).
- `Task02/` – claim validation, exception handling and rethrowing (B2).
- `Task03/` – virtual vs switch benchmark starter and measurement instructions (B3).
- `Task04/` – extension example and final engineering decision (B4).
- `Screenshots/` – add your own terminal output screenshots.
- `TestInputs/` – sample test cases.

## Task results
- Task 01: Demonstrates an abstract `Bill` class, overridden functions and runtime polymorphism.
- Task 02: Demonstrates validation exceptions, custom `ClaimError`, logging and rethrowing.
- Task 03: Contains a benchmark program starter. Run it on your computer and record actual timings.
- Task 04: Demonstrates adding an emergency bill and a corporate payer without modifying existing classes.

## Before submission
1. Replace the compiler-version placeholder with the output of `g++ --version`.
2. Compile and run every program yourself.
3. Add genuine screenshots to `Screenshots/`.
4. Add measured timing results to `Task03/measurements.md`.
5. Run AddressSanitizer where supported and save the actual report.
6. Commit each task separately; do not upload everything in one final commit.
7. Share this repository with your faculty as required by the assignment.

**Note:** Screenshots, sanitizer reports and benchmark timings are intentionally left for your own execution. Do not present sample/expected output as proof of execution.
