# PART A – DESIGN

## A1 – Polymorphic Bill Hierarchy

### A1.1 Common interface
Every bill provides:
- `total()`: calculates the bill amount.
- `type()`: returns the bill category.
- `print()`: displays bill details.

Common data can include patient name, patient ID, bill number and billing date.

### A1.2 Hierarchy
`Bill` is an abstract base class with pure virtual `total()` and `type()` functions and a virtual destructor.

Derived classes:
- `OutPatientBill`: consultation and test charges.
- `InPatientBill`: room charges per day, procedures and medicines.
- `DayCareBill`: package price.
- `EmergencyBill`: base charge and time-based charges.

```text
                 Bill (abstract)
             + total() = 0
             + type() = 0
             + virtual destructor
                      |
       +--------------+--------------+--------------+
       |              |              |              |
 OutPatientBill  InPatientBill  DayCareBill  EmergencyBill
```

Derived classes override `total()` and `type()`. `print()` may be implemented once in the base class and call the virtual functions.

### A1.3 Pseudocode
```text
ALGORITHM CalculateDailyTotal
START
    dailyTotal ← 0
    FOR each billPointer in bills
        dailyTotal ← dailyTotal + billPointer.total()
    END FOR
    PRINT dailyTotal
STOP
```

### Alternative: structure and switch
A single structure can store a type code and bill data; `total()` uses a switch on that code. Both approaches take O(n) time to total n bills. The structure approach may avoid per-object vtable-pointer overhead, but needs enough storage for its fields. Adding a type requires modifying the switch and often the structure. With virtual functions, a new derived class can be added without changing existing bill classes.

## A2 – Runtime Binding

### A2.1 Early and late binding
Early binding selects a non-virtual function at compile time. Late binding selects an overridden virtual function at runtime based on the actual object. For `Bill* b`, `b->total()` calls the derived implementation when `total()` is virtual.

### A2.2 Conceptual vtables
```text
Bill vtable:
  total -> pure virtual
  type  -> pure virtual
  destructor -> Bill destructor

OutPatientBill vtable:
  total -> OutPatientBill::total
  type  -> OutPatientBill::type
  destructor -> OutPatientBill destructor

InPatientBill vtable:
  total -> InPatientBill::total
  type  -> InPatientBill::type
  destructor -> InPatientBill destructor
```
A compiler's actual vtable layout is implementation-specific; this is a conceptual diagram.

### A2.3 Virtual destructor
A virtual base destructor ensures that deleting a derived object through a base pointer invokes the derived destructor and then the base destructor. Without it, the behaviour is undefined.

### Predict output
For the supplied `OPBill` example:
```text
500 ~OPBill ~Bill
```
`show()` is non-virtual, but it calls virtual `total()`, so `OPBill::total()` runs. Deleting through `Bill*` invokes the derived destructor first and then the base destructor because the base destructor is virtual. Removing `virtual` from the base destructor makes deletion through the base pointer undefined behaviour; sanitizer output is implementation-dependent.

### Alternative: dynamic_cast
Without virtual `total()`, code could test each possible derived type using `dynamic_cast` and call its calculation. With k types, this may require up to O(k) checks per bill, while virtual dispatch is O(1) per call. A polymorphic object commonly carries a vptr; exact object layout is implementation-specific.

## A3 – Abstract Payer

```cpp
class Payer {
public:
    virtual double amountCovered(const Bill& bill) const = 0;
    virtual ~Payer() = default;
};
```
Derived payer classes:
- `SelfPay`: patient pays the full bill.
- `Insurance`: applies policy cover limit and co-payment percentage.
- `GovernmentScheme`: applies fixed package rates.

A new `CorporatePayer` can derive from `Payer` and implement `amountCovered()` without modifying existing payer classes.

### Alternative: function objects
A function pointer or `std::function` can hold a policy calculation. Both function-object invocation and virtual dispatch are generally O(1). An abstract class stores policy data in object members; a callable can capture data or refer to external policy data.

## A4 – Exception Strategy

Possible errors:
- Negative charges.
- Claim above cover.
- Unknown package.
- Missing patient record.
- Allocation failure (`std::bad_alloc`).

A custom hierarchy may be:
```text
std::exception
  └── BillingError
       ├── ClaimError
       ├── InvalidChargeError
       ├── PackageError
       └── PatientRecordError
```
`std::bad_alloc` is a separate standard exception type.

Validation, lookup and calculation functions may throw. Destructors and cleanup functions should not throw; destructors are normally `noexcept`. Throwing during stack unwinding can terminate the program.

### Alternative: return codes
An enum status or boolean plus an error message can report errors. The caller must check each result and propagate status information. Normal-path performance is predictable; error handling is explicit. Exceptions separate error paths from normal control flow but can be expensive when thrown frequently.

## A5 – Recovery and Rethrowing

The validation/service layer catches an exception to log context and uses `throw;` to rethrow the same exception. The top-level application catches it and reports a clear message.

Stack unwinding destroys automatic local objects as the exception moves up the call stack. RAII types such as `std::string`, `std::vector` and `std::unique_ptr` release their resources through destructors.

### Predict output
For the supplied Guard example:
```text
~f ~main caught 42
```
The local guard in `f()` is destroyed first, then the guard in `main()`. The `throw` transfers control to the matching handler, so `not printed` is skipped.

### Alternative: manual delete
Manual cleanup in every catch block has similar cleanup time per resource but increases code and the chance of forgetting cleanup on a new error path. RAII centralizes cleanup in destructors.
