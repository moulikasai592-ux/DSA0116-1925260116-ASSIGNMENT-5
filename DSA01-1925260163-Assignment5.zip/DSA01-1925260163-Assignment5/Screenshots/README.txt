Place your genuine terminal screenshots in this folder.
Suggested files:
- Task01-output.png
- Task02-output.png
- Task03-benchmark.png
- Task04-output.png
- AddressSanitizer-report.png

Do not place fabricated screenshots here.
