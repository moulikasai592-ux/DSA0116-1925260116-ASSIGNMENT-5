#include <chrono>
#include <iostream>
#include <vector>

struct BillData {
    int type;
    double amount;
};

double virtualTotal(const std::vector<BillData>& bills) {
    // This simple baseline stores values in a common structure.
    // Replace/extend with your polymorphic hierarchy for a true virtual benchmark.
    double sum = 0.0;
    for (const auto& b : bills) sum += b.amount;
    return sum;
}

double switchTotal(const std::vector<BillData>& bills) {
    double sum = 0.0;
    for (const auto& b : bills) {
        switch (b.type) {
            case 1: sum += b.amount; break;
            case 2: sum += b.amount; break;
            case 3: sum += b.amount; break;
            case 4: sum += b.amount; break;
            default: break;
        }
    }
    return sum;
}

template <typename Function>
void measure(const char* label, Function fn) {
    const auto start = std::chrono::steady_clock::now();
    const double result = fn();
    const auto end = std::chrono::steady_clock::now();
    const auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(
        end - start).count();
    std::cout << label << ": total=" << result << ", time=" << ms << " ms\n";
}

int main() {
    for (const int n : {1000, 1000000, 10000000}) {
        std::vector<BillData> bills;
        bills.reserve(static_cast<std::size_t>(n));
        for (int i = 0; i < n; ++i)
            bills.push_back({(i % 4) + 1, 100.0 + (i % 100)});

        std::cout << "Bills: " << n << '\n';
        measure("Linear baseline", [&] { return virtualTotal(bills); });
        measure("Switch", [&] { return switchTotal(bills); });
    }
}
