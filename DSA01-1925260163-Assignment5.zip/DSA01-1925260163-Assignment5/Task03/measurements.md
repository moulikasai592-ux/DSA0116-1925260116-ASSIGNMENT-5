# B3 Measurements

Compile with optimization:
```bash
g++ -std=c++17 -O2 -Wall -Wextra benchmark.cpp -o benchmark
```

Run the program and paste your actual output here.

| Number of bills | Virtual implementation (ms) | Switch implementation (ms) |
|---:|---:|---:|
| 1,000 | Fill after running | Fill after running |
| 1,000,000 | Fill after running | Fill after running |
| 10,000,000 | Fill after running | Fill after running |

**Important:** The included benchmark is a starter and its `Linear baseline` is not yet a true virtual-function implementation. Implement the polymorphic version before claiming a virtual-vs-switch comparison. Run repeated trials and report the average.
